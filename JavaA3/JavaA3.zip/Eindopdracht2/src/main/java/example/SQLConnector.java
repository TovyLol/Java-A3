package example;

import java.sql.*;

public class SQLConnector {
    private Connection c = null;

    public SQLConnector() throws Exception {

        String url = "jdbc:mysql://localhost/Personen2?serverTimezone=UTC";
        c = DriverManager.getConnection(url, "Jasper", "");
    }

    public void createTable() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS personen (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "voornaam VARCHAR(100), " +
                "achternaam VARCHAR(100)" +
                ")";
        try (Statement s = c.createStatement()) {
            s.executeUpdate(createTableSQL);
        }
    }

    public void insertPersoon(Persoon persoon) throws SQLException {
        String insertSQL = "INSERT INTO personen (voornaam, achternaam) VALUES (?, ?)";
        try (PreparedStatement p = c.prepareStatement(insertSQL)) {
            p.setString(1, persoon.getVoornaam());
            p.setString(2, persoon.getAchternaam());
            p.executeUpdate();
        }
    }

    public ResultSet getPersonen() throws SQLException {
        String querySQL = "SELECT * FROM personen";
        Statement s = c.createStatement();
        return s.executeQuery(querySQL);
    }

    public void close() throws SQLException {
        if (c != null && !c.isClosed()) {
            c.close();
        }
    }
}
