package example;

import javax.swing.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private List<Persoon> personenLijst;
    private DefaultListModel<Persoon> model;
    private SQLConnector connector;

    public Controller(DefaultListModel<Persoon> model) throws Exception {
        this.personenLijst = new ArrayList<>();
        this.model = model;
        this.connector = new SQLConnector();
        connector.createTable();
        loadPersonenFromDB();
    }

    public void voegPersoonToe(String voornaam, String achternaam) {
        Persoon persoon = new Persoon(voornaam, achternaam);
        personenLijst.add(persoon);
        model.addElement(persoon);
        try {
            connector.insertPersoon(persoon);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Persoon> getPersonenLijst(){
        return personenLijst;
    }

    private void loadPersonenFromDB() throws SQLException {
        ResultSet rs = connector.getPersonen();
        while (rs.next()) {
            String voornaam = rs.getString("voornaam");
            String achternaam = rs.getString("achternaam");
            Persoon persoon = new Persoon(voornaam, achternaam);
            personenLijst.add(persoon);
            model.addElement(persoon);
        }
    }
}
