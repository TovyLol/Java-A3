package example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private JTextField voornaamVeld, achternaamVeld;
    private JButton voegToeKnop;
    private DefaultListModel<Persoon> personenModel;
    private JList<Persoon> personenLijst;
    private Controller controller;

    public Main() throws Exception {
        setTitle("Diddy list");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        personenModel = new DefaultListModel<>();
        personenLijst = new JList<>(personenModel);

        controller = new Controller(personenModel);

        JPanel invoerPaneel = new JPanel(new GridLayout(3, 2));
        invoerPaneel.add(new JLabel("Voornaam:"));
        voornaamVeld = new JTextField();
        invoerPaneel.add(voornaamVeld);

        invoerPaneel.add(new JLabel("Achternaam:"));
        achternaamVeld = new JTextField();
        invoerPaneel.add(achternaamVeld);

        voegToeKnop = new JButton("Toevoegen");
        invoerPaneel.add(voegToeKnop);

        add(new JScrollPane(personenLijst), BorderLayout.CENTER);
        add(invoerPaneel, BorderLayout.NORTH);

        voegToeKnop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String voornaam = voornaamVeld.getText();
                String achternaam = achternaamVeld.getText();
                if (!voornaam.isEmpty() && !achternaam.isEmpty()) {
                    controller.voegPersoonToe(voornaam, achternaam);
                    voornaamVeld.setText("");
                    achternaamVeld.setText("");
                } else {
                    JOptionPane.showMessageDialog(Main.this,
                            "Voeg alle info toe", "Diddy lijst ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new Main().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}