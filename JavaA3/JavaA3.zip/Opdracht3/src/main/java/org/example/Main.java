package org.example;

public class Main {
    public static void main(String[] args) {
        Auto mijnAuto = new Auto("Tesla", "Model Y", 2022, 1972, "Elektrisch", "BG-233-G", 0);
        double belasting = mijnAuto.berekenBelasting();
        System.out.println("De wegenbelasting voor de auto is: €" + belasting);
    }
}
