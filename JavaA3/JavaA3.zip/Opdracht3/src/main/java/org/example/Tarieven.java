package org.example;

public class Tarieven {
    private Vervoermiddel vervoermiddel;
    private double CO2uitstoot;
    private double basiskost = 50.00;
    private double gewichtkost;
    private double wegenbelasting;

    public Tarieven(Vervoermiddel v, double CO2uitstoot) {
        this.vervoermiddel = v;
        this.CO2uitstoot = CO2uitstoot;
    }

    public double berekenBelasting() {
        if (vervoermiddel != null && vervoermiddel.getGewicht() <= 750) {
            gewichtkost = 20.00;
        } else if (vervoermiddel != null && vervoermiddel.getGewicht() <= 1000) {
            gewichtkost = 40.00;
        } else if (vervoermiddel != null && vervoermiddel.getGewicht() <= 1500) {
            gewichtkost = 60.00;
        } else if (vervoermiddel != null && vervoermiddel.getGewicht() > 1500) {
            gewichtkost = 80.00;
        }

        double CO2Tarief = 0;
        if (CO2uitstoot > 95) {
            CO2Tarief = (CO2uitstoot - 95) * 0.10;
        }

        wegenbelasting = basiskost + gewichtkost + CO2Tarief;
        return wegenbelasting;
    }
}
