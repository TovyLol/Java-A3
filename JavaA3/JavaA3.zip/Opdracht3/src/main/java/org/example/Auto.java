package org.example;

public class Auto extends Vervoermiddel {
    private String brandstof;
    private String kenteken;
    private double CO2Uitstoot;

    public Auto(String merk, String model, int bouwjaar, double gewicht, String brandstof, String kenteken, double CO2Uitstoot) {
        super(merk, model, bouwjaar, gewicht);
        this.brandstof = brandstof;
        this.kenteken = kenteken;
        this.CO2Uitstoot = CO2Uitstoot;
    }

    @Override
    public double berekenBelasting() {
        Tarieven tarieven = new Tarieven(this, CO2Uitstoot);
        return tarieven.berekenBelasting();
    }
    public String getBrandstof() {
        return brandstof;
    }

    public String getKenteken() {
        return kenteken;
    }
}
