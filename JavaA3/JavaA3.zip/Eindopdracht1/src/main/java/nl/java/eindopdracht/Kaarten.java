package nl.java.eindopdracht;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kaarten {
    private JButton b;
    private String imagePath;
    private boolean isR;
    private boolean isM;
    private Controller c;

    public Kaarten(String imagePath, Controller c) {
        this.imagePath = imagePath;
        this.c = c;
        this.isR = false;
        this.isM = false;
        this.b = new JButton();
        b.setPreferredSize(new Dimension(100, 150));
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                c.eventbuttonC(Kaarten.this);
            }
        });
    }
// krijgt alle buttons en paths
    public JButton getButton() {
        return b;
    }

    public String getPath() {
        return imagePath;
    }
//boolean voor kaarten
    public boolean isR() {
        return isR;
    }

    public void R() {
        this.isR = true;
        b.setIcon(new ImageIcon(imagePath)); //erbij
    }

    public void hide() {
        this.isR = false;
        b.setIcon(null); //weg ermee
    }
    //boolean zodat de plaatjes niet verdwijnen als ze matchen
    public void setM(boolean matched) {
        this.isM = matched;
    }
}
