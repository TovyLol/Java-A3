package nl.java.eindopdracht;

import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private Board board;
    private Kaarten eersteKaart, tweedeKaart;
    private boolean isDoingSomething;

    public Controller() {
        board = new Board(this);
        eersteKaart = null;
        tweedeKaart = null;
        isDoingSomething = false;
    }

    public void start() {
        board.getB();
    }
//checkt of er op een kaart is geclickt
    public void eventbuttonC(Kaarten card) {
        if (isDoingSomething || card.isR()) {
            return;
        }
        card.R();

        if (eersteKaart == null) {
            eersteKaart = card;
        } else {
            tweedeKaart = card;
            eventcMatch();
        }
    }
// checkt of er kaarten matchen
    private void eventcMatch() {
        isDoingSomething = true;

        Timer t = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (eersteKaart.getPath().equals(tweedeKaart.getPath())) {
                    eersteKaart.setM(true);
                    tweedeKaart.setM(true);
                } else {
                    eersteKaart.hide();
                    tweedeKaart.hide();
                }

                eersteKaart = null;
                tweedeKaart = null;
                isDoingSomething = false;
            }
        });

        t.setRepeats(false);
        t.start();
    }
}
