package nl.java.eindopdracht;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Board {
    private JFrame frame;
    private JButton resetB;
    private List<Kaarten> kaarten;
    private Controller controller;

    public Board(Controller controller) {
        this.controller = controller;
        frame = new JFrame("Memory");
        frame.setLayout(new GridLayout(5, 4));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        kaarten = new ArrayList<>();
        iButtons();

        resetB = new JButton("Reset");
        resetB.addActionListener(e -> rBoard());
        frame.add(resetB);
    }
// window essentie
    public void getB() {
        frame.setSize(500, 600);
        frame.setVisible(true);
    }
//geeft iedere button een plaatje en zorgt voor niet meer dan 2 plaatjes over het hele board
    private void iButtons() {
        List<String> imagePaths = loadKatten();
        Collections.shuffle(imagePaths);

        for (int i = 0; i < 16; i++) {
            Kaarten card = new Kaarten(imagePaths.get(i), controller);
            kaarten.add(card);
            frame.add(card.getButton());
        }
    }
//krijgt alle plaatjes en gooit ze in een array
    //return
    private List<String> loadKatten() {
        List<String> kattenPath = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            String path = "plaatjes/" + i + ".jpg";
            kattenPath.add(path);
            kattenPath.add(path);
        }
        return kattenPath;
    }
// reset function
    private void rBoard() {
        frame.getContentPane().removeAll();
        kaarten.clear();

        iButtons();
        frame.add(resetB);
        frame.revalidate();
        frame.repaint();
    }
}
