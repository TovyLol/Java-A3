package org.example;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private List<Persoon> personenLijst;
    private DefaultListModel<Persoon> model;

    public Controller(DefaultListModel<Persoon> model) {
        this.personenLijst = new ArrayList<>();
        this.model = model;
    }
    public void voegPersoonToe(String voornaam, String achternaam) {
        Persoon persoon = new Persoon(voornaam, achternaam);
        personenLijst.add(persoon);
        model.addElement(persoon);
    }
    public List<Persoon> getPersonenLijst(){
        return personenLijst;
    }

}
