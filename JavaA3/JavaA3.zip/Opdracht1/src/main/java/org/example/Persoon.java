package org.example;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Persoon {
    public String voornaam = "Jasper";
    public String achternaam = "B";
    public Date geboortedatum = new Date(2006, 9, 22);
}
